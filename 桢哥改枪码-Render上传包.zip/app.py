"""桢哥改枪码 - 本地/公网网页服务"""
import json
import os
from pathlib import Path

from flask import Flask, jsonify, render_template, request

APP_DIR = Path(__file__).resolve().parent
DATA_PATH = APP_DIR / "data.json"

app = Flask(__name__)


def load_records() -> list[dict]:
    if not DATA_PATH.exists():
        return []
    with open(DATA_PATH, encoding="utf-8") as f:
        return json.load(f)


RECORDS = load_records()


def _weapon_hints() -> list[dict]:
    counts: dict[str, int] = {}
    for r in RECORDS:
        name = r.get("weapon", "")
        if name:
            counts[name] = counts.get(name, 0) + 1
    return [{"name": name, "count": counts[name]} for name in sorted(counts.keys())]


@app.route("/")
def index():
    weapons = sorted({r["weapon"] for r in RECORDS if r["weapon"]})
    mod_levels = sorted({r["mod_level"] for r in RECORDS if r["mod_level"]})
    strengths = sorted({r["strength"] for r in RECORDS if r["strength"]})
    return render_template(
        "index.html",
        total=len(RECORDS),
        weapons=weapons,
        weapon_hints=_weapon_hints(),
        mod_levels=mod_levels,
        strengths=strengths,
    )


@app.route("/api/search")
def search():
    q = request.args.get("q", "").strip().lower()
    weapon = request.args.get("weapon", "").strip()
    mod_level = request.args.get("mod_level", "").strip()
    strength = request.args.get("strength", "").strip()

    results = RECORDS
    if weapon:
        results = [r for r in results if r["weapon"] == weapon]
    if mod_level:
        results = [r for r in results if r["mod_level"] == mod_level]
    if strength:
        results = [r for r in results if r["strength"] == strength]
    if q:
        results = [
            r
            for r in results
            if q in r.get("search_text", "") or q in r.get("code", "").lower()
        ]

    return jsonify({"count": len(results), "items": results[:200]})


@app.route("/api/suggest")
def suggest():
    q = request.args.get("q", "").strip().lower()
    if not q:
        return jsonify([])
    matched = [h for h in _weapon_hints() if q in h["name"].lower() or q in h["name"]][:12]
    return jsonify(matched)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "").lower() in ("1", "true")
    print("=" * 50)
    print("桢哥改枪码 已启动")
    print(f"请在浏览器打开: http://127.0.0.1:{port}")
    print("=" * 50)
    app.run(host="0.0.0.0", port=port, debug=debug)
